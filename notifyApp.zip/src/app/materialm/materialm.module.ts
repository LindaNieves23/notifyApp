import { NgModule } from '@angular/core';
import { MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatDividerModule,
  MatTableModule, MatIconModule, MatToolbarModule, MatMenuModule, MatSnackBarModule, MatSidenavModule, MatCheckboxModule, MatDialogModule
   } from '@angular/material';
const modules_material = [
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatDividerModule,
  MatTableModule,
  MatIconModule,
  MatToolbarModule,
  MatMenuModule,
  MatSnackBarModule,
  MatSidenavModule,
  MatCheckboxModule,
  MatDialogModule];
@NgModule({
  imports: modules_material,
  exports: modules_material
})
export class MaterialmModule { }
