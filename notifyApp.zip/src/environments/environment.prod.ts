export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyBrUrXD2OuDu4XtADNZYwsnwjTJf4faU6s',
    authDomain: 'taller1-7e7e0.firebaseapp.com',
    databaseURL: 'https://taller1-7e7e0.firebaseio.com',
    projectId: 'taller1-7e7e0',
    storageBucket: 'taller1-7e7e0.appspot.com',
    messagingSenderId: '873631209942'
  }
};
