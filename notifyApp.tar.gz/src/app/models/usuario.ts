export interface Usuario {
    uid: string;
    email: string;
    pass?: string;
    nombre?: string;
    apellido?: string;
    telefono?: string;
}
