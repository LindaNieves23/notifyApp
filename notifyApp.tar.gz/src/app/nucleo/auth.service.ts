import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFirestore, AngularFirestoreDocument } from 'angularfire2/firestore';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';
import { Usuario } from '../models/usuario';

@Injectable()
export class AuthService {

  usuario: Observable<Usuario>;

  constructor(private afAuth: AngularFireAuth,
    private afs: AngularFirestore,
    private router: Router) {

    //// Get auth data, then get firestore user document || null
    this.usuario = this.afAuth.authState
      .switchMap(usuario => {
        if (usuario) {
          return this.afs.doc<Usuario>(`users/${usuario.uid}`).valueChanges();
        } else {
          return Observable.of(null);
        }
      });
  }

  emailSignUp(email: string, password: string) {
    return this.afAuth.auth.createUserWithEmailAndPassword(email, password)
      .then(usuario => {
        return this.setUserDoc(usuario); // create initial user document
      })
      .catch(error => this.handleError(error) );
  }

  private setUserDoc(usuario) {

    const userRef: AngularFirestoreDocument<Usuario> = this.afs.doc(`contactos/${usuario.uid}`);

    const data: Usuario = {
      uid: usuario.uid,
      email: usuario.email || null,
      nombre: usuario.nombre,
      apellido: usuario.apellido,
      telefono: usuario.telefono
    };

    return userRef.set(data);

  }

  // Update properties on the user document
  updateUser(usuario: Usuario, data: any) {
    return this.afs.doc(`contactos/${usuario.uid}`).update(data);
  }



  // If error, console log and notify user
  private handleError(error) {
    console.error(error);
    // this.notify.update(error.message, 'error')
  }

  /// Additional useful methods, not used in video
  emailLogin(email: string, password: string) {
    return this.afAuth.auth.signInWithEmailAndPassword(email, password)
      .catch(error => this.handleError(error) );
  }

  // Sends email allowing user to reset password
  resetPassword(email: string) {
    const fbAuth = firebase.auth();

    return fbAuth.sendPasswordResetEmail(email)
      .then(() => console.log('Password update email sent'))
      .catch((error) => this.handleError(error) );
  }


  signOut() {
    this.afAuth.auth.signOut().then(() => {
        this.router.navigate(['/']);
    });
  }

}
