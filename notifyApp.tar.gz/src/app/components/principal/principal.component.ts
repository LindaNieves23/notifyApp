import { Component, OnInit } from '@angular/core';
import { Usuario } from '../../models/usuario';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {
  rusuario: Usuario = {
    uid: '',
    email: ''
  };
  constructor() { }

  ngOnInit() {
  }

}
